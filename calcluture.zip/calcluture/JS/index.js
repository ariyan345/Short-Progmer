var outputField = $("#showInput");


function insertNumber(namber) {
    var olldNamber = outputField.val();
    $("#showInput").val(olldNamber + namber);
}

function clearRes() {
    outputField.val('');
}

function showResult() {

    var myResult = eval(outputField.val());
    outputField.val(myResult);
}


function deleteNamber() {

    var presentValue = outputField.val();

    if (presentValue != '') {
        outputField.val(presentValue.slice(0, -1));
    }

}
