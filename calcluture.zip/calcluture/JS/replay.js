var findBox = $("#showInput");



function insertNumber(mynumber) {
    var showNamber = findBox.val();
    findBox.val(showNamber + mynumber);
}

function clearRes() {
    var removeValue = findBox.val();
    findBox.val('')
}

function showResult() {
    var evalElement = eval(findBox.val());
    findBox.val(evalElement);
}

function deleteNamber() {

    var prasentValue = findBox.val();

    if (prasentValue != "") {
        findBox.val(prasentValue.slice(0, -1));
    }

}
